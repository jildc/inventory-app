KINLOVE INVENTORY — EASY GITHUB PAGES

Files are already named correctly. Upload ALL files and folders to the root of your GitHub Pages repository:
- index.html
- manifest.json
- sw.js
- logo.jpg
- icons/ (keep this folder)

Important: do not rename the files inside icons/.

Default password: 1234
Change it from the Password button after unlocking.

The app stores inventory locally on each phone and works offline after it has loaded once online. It does NOT sync between phones.

Home Screen icon: the iPhone uses apple-touch-icon.png; Android uses the manifest icons.
